(function(){
	'use strict'

	angular.module('slider_cards',[]);

	$(document).ready(function(){
		$('.slider').slider({full_width: false});
	});
})();
